
import { Property, Agent } from './types';

export const COLORS = {
  NAVY: '#1a237e',
  GOLD: '#ffd700',
  SILVER: '#c0c0c0',
  TEXT_LIGHT: '#f8fafc',
  TEXT_DARK: '#0f172a'
};

// 您的 WhatsApp 联系号码: +44 7951 458082
export const WHATSAPP_NUMBER = '447951458082';

export const PROPERTIES: Property[] = [
  {
    id: 'GH-001',
    title: 'The Sky-Garden Penthouse',
    price: 'GHS 8,500,000',
    location: 'Cantonments, Accra',
    specs: '4 Beds | 320 sqm',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1200',
    type: 'apartment',
    budgetLevel: 'luxury'
  },
  {
    id: 'GH-002',
    title: 'Royal Palms Estate',
    price: 'GHS 15,200,000',
    location: 'East Legon, Accra',
    specs: '6 Beds | Private Pool',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1200',
    type: 'villa',
    budgetLevel: 'ultra-luxury'
  },
  {
    id: 'GH-003',
    title: 'The Platinum Suites',
    price: 'GHS 4,800,000',
    location: 'Labone, Accra',
    specs: '3 Beds | Smart Home',
    image: 'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&q=80&w=1200',
    type: 'apartment',
    budgetLevel: 'premium'
  },
  {
    id: 'GH-004',
    title: 'Diplomatic Enclave Manor',
    price: 'GHS 22,000,000',
    location: 'Airport Residential',
    specs: 'Detached Mansion | 1.2 Acres',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1200',
    type: 'villa',
    budgetLevel: 'ultra-luxury'
  }
];

export const AGENTS: Agent[] = [
  { id: 'A01', name: 'Director Kofi Amoah', level: 'partner', specialty: 'Diplomatic Zone Specialist', phone: '447951458082', regions: ['Cantonments', 'Airport Residential'] },
  { id: 'A02', name: 'Sandra Mensah', level: 'senior', specialty: 'Investment ROI Analyst', phone: '447951458082', regions: ['East Legon', 'Labone'] },
  { id: 'A03', name: 'Kwame Osei', level: 'principal', specialty: 'Prime Land Expert', phone: '447951458082', regions: ['Ridge', 'Dzorwulu'] }
];

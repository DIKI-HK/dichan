
export interface Property {
  id: string;
  title: string;
  price: string;
  location: string;
  specs: string;
  image: string;
  type: 'apartment' | 'villa' | 'commercial';
  budgetLevel: 'premium' | 'luxury' | 'ultra-luxury';
}

export interface Agent {
  id: string;
  name: string;
  level: 'senior' | 'principal' | 'partner';
  specialty: string;
  phone: string;
  regions: string[];
}

export interface Lead {
  name: string;
  email: string;
  phone: string;
  budget: number;
  purpose: 'investment' | 'residential';
  location?: string;
}

export enum SectionId {
  Home = 'home',
  About = 'about',
  Services = 'services',
  Featured = 'featured',
  Testimonials = 'testimonials',
  Contact = 'contact'
}

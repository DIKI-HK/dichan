
import React, { useState, useEffect } from 'react';
import { WHATSAPP_NUMBER } from '../constants';

const WhatsAppWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showDot, setShowDot] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowDot(true), 15000);
    return () => clearTimeout(timer);
  }, []);

  const quickReplies = [
    { text: 'Book a Viewing', msg: "Hello, I'd like to book a property viewing. What times are available?" },
    { text: 'Price Inquiry', msg: "Hello, I'm interested in the current market pricing. Can you provide a quotation?" },
    { text: 'Investment Analysis', msg: "Hello, I'm planning an investment and need a professional ROI analysis." },
  ];

  const handleWhatsAppClick = (message: string) => {
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed bottom-6 right-6 md:bottom-8 md:right-8 z-[60] flex flex-col items-end">
      {isOpen && (
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-4 w-72 md:w-80 border border-gray-100 animate-fade-in-up">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white">
              <i className="fab fa-whatsapp text-xl"></i>
            </div>
            <div>
              <p className="font-bold text-slate-800">Elite Support</p>
              <p className="text-xs text-green-600 flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span> Online Now
              </p>
            </div>
          </div>
          <p className="text-sm text-slate-600 mb-4">Welcome! I'm your dedicated real estate advisor. How may I assist you today?</p>
          <div className="space-y-2">
            {quickReplies.map((reply, idx) => (
              <button
                key={idx}
                onClick={() => handleWhatsAppClick(reply.msg)}
                className="w-full text-left text-xs bg-gray-50 hover:bg-[#ffd700] hover:text-[#1a237e] p-3 rounded-lg transition-all border border-gray-200"
              >
                {reply.text}
              </button>
            ))}
          </div>
        </div>
      )}

      <button
        onClick={() => {
          setIsOpen(!isOpen);
          setShowDot(false);
        }}
        className="relative w-14 h-14 md:w-16 md:h-16 bg-[#ffd700] rounded-full shadow-xl flex items-center justify-center text-[#1a237e] hover:scale-110 transition-transform whatsapp-bounce group"
      >
        <i className={`fab fa-whatsapp text-2xl md:text-3xl group-hover:rotate-12 transition-transform`}></i>
        {showDot && !isOpen && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 border-2 border-white rounded-full flex items-center justify-center text-[10px] text-white font-bold">
            1
          </span>
        )}
      </button>
    </div>
  );
};

export default WhatsAppWidget;


import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { WHATSAPP_NUMBER } from '../constants';

const LeadFormPopup: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [aiResponse, setAiResponse] = useState<string>('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    budget: '',
    purpose: 'investment' as 'investment' | 'residential'
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      const alreadySubmitted = localStorage.getItem('lead_submitted');
      if (!alreadySubmitted) setIsVisible(true);
    }, 8000);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Submit to Formspree via luckily945@gmail.com
      const response = await fetch('https://formspree.io/luckily945@gmail.com', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json' 
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          _replyto: formData.email,
          budget: formData.budget,
          purpose: formData.purpose,
          _subject: `New Premium Lead: ${formData.name}`,
          message: `Lead Details:\nName: ${formData.name}\nEmail: ${formData.email}\nBudget: ${formData.budget}\nPurpose: ${formData.purpose}`
        })
      });

      // Call Gemini for an elite welcome message in English
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `You are a high-end real estate director based in Accra, Ghana. 
      A client named ${formData.name} with a budget of ${formData.budget} for ${formData.purpose === 'investment' ? 'investment' : 'residential living'} has just registered.
      Write a 2-sentence sophisticated, elite welcome message.
      Conclude with: 'Your requirements have been securely forwarded to my private office at luckily945@gmail.com. I will contact you personally within the hour.'`;

      const aiRes = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      setAiResponse(aiRes.text || "Thank you for your inquiry. A director will contact you shortly.");
      
      localStorage.setItem('lead_submitted', 'true');
      setIsSubmitted(true);
    } catch (err) {
      console.error("Submission error:", err);
      setIsSubmitted(true);
      setAiResponse("Submission received. Our Director (luckily945@gmail.com) has been notified and will contact you within the hour.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBackupWhatsApp = () => {
    const msg = `Hello, I am ${formData.name}. I just registered on Elite Estate (Budget: ${formData.budget}). Looking forward to your consultation.`;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-[#0f172a]/95 backdrop-blur-md" onClick={() => !isSubmitting && setIsVisible(false)}></div>
      <div className="relative bg-[#1a237e] text-white w-full max-w-lg rounded-3xl overflow-hidden shadow-[0_0_80px_rgba(255,215,0,0.2)] animate-fade-in border border-white/10">
        {!isSubmitting && (
          <button 
            onClick={() => setIsVisible(false)}
            className="absolute top-6 right-6 text-white/30 hover:text-white transition-colors z-10"
          >
            <i className="fas fa-times text-xl"></i>
          </button>
        )}
        
        <div className="p-10 md:p-14">
          {!isSubmitted ? (
            <>
              <div className="mb-10 text-center">
                <span className="text-[#ffd700] text-[10px] font-bold tracking-[0.4em] uppercase border-b border-[#ffd700]/30 pb-2 inline-block mb-4">Private Portfolio Access</span>
                <h2 className="text-3xl md:text-4xl font-serif-luxury mb-4">Exclusive Market Briefing</h2>
                <p className="text-white/40 font-light text-sm">
                  Register to receive our confidential list of off-market properties in Accra's prime sectors.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <i className="fas fa-user absolute left-4 top-1/2 -translate-y-1/2 text-white/20 text-xs"></i>
                  <input 
                    type="text" 
                    placeholder="Full Name" 
                    required 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-[#ffd700] transition-all placeholder:text-white/20"
                  />
                </div>
                <div className="relative">
                  <i className="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-white/20 text-xs"></i>
                  <input 
                    type="email" 
                    placeholder="Email Address" 
                    required 
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-[#ffd700] transition-all placeholder:text-white/20"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <select 
                    required
                    value={formData.budget}
                    onChange={(e) => setFormData({...formData, budget: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-4 text-white/50 focus:outline-none focus:border-[#ffd700] transition-all appearance-none text-sm"
                  >
                    <option value="" className="bg-[#1a237e]">Budget Range</option>
                    <option value="GHS 1M - 5M" className="bg-[#1a237e]">GHS 1M - 5M</option>
                    <option value="GHS 5M - 15M" className="bg-[#1a237e]">GHS 5M - 15M</option>
                    <option value="GHS 15M+" className="bg-[#1a237e]">GHS 15M+</option>
                  </select>
                  <select 
                    required
                    value={formData.purpose}
                    onChange={(e) => setFormData({...formData, purpose: e.target.value as any})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-4 text-white/50 focus:outline-none focus:border-[#ffd700] transition-all appearance-none text-sm"
                  >
                    <option value="investment" className="bg-[#1a237e]">Investment</option>
                    <option value="residential" className="bg-[#1a237e]">Residential</option>
                  </select>
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full gold-gradient py-5 rounded-xl text-[#1a237e] font-bold text-sm tracking-[0.2em] uppercase hover:brightness-110 active:scale-[0.98] transition-all shadow-2xl mt-4 flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <><i className="fas fa-circle-notch animate-spin mr-3"></i> Securing Access...</>
                  ) : 'Request Portfolio Access'}
                </button>
              </form>
            </>
          ) : (
            <div className="text-center py-6 animate-fade-in">
              <div className="w-24 h-24 bg-[#ffd700] rounded-3xl flex items-center justify-center mx-auto mb-10 shadow-[0_20px_40px_rgba(255,215,0,0.3)]">
                <i className="fas fa-check-double text-[#1a237e] text-4xl"></i>
              </div>
              <h2 className="text-3xl font-serif-luxury mb-6 text-[#ffd700]">Submission Successful</h2>
              <div className="bg-white/5 border border-white/10 p-8 rounded-2xl text-left mb-6 relative">
                <p className="text-white/80 text-sm leading-relaxed italic font-light">
                  {aiResponse}
                </p>
              </div>

              {/* Activation Notice */}
              <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-xl mb-10 text-left">
                <p className="text-[#ffd700] text-[10px] font-bold uppercase tracking-widest mb-2 flex items-center">
                  <i className="fas fa-info-circle mr-2"></i> Activation Required
                </p>
                <p className="text-white/60 text-[10px] leading-relaxed">
                  Please check <strong>luckily945@gmail.com</strong> for an email from Formspree to <strong>Activate</strong> this form. If it's not in your inbox, check the Spam folder.
                </p>
              </div>
              
              <div className="space-y-4">
                <button 
                  onClick={handleBackupWhatsApp}
                  className="w-full bg-green-500 hover:bg-green-600 text-white py-4 rounded-xl font-bold text-xs uppercase tracking-widest flex items-center justify-center transition-all shadow-lg"
                >
                  <i className="fab fa-whatsapp mr-3 text-lg"></i> Confirm via WhatsApp
                </button>
                <a 
                  href="mailto:luckily945@gmail.com?subject=New Lead Registered&body=I have registered my details on the Elite Estate website."
                  className="w-full bg-white/5 border border-white/10 hover:bg-white/10 text-white py-4 rounded-xl font-bold text-xs uppercase tracking-widest flex items-center justify-center transition-all"
                >
                  <i className="fas fa-envelope-open mr-3"></i> Send Direct Email
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeadFormPopup;

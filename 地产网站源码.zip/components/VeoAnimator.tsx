
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

const LOADING_MESSAGES = [
  "Analyzing architectural spatial data...",
  "Mapping high-resolution textures...",
  "Applying cinematic atmospheric lighting...",
  "Synthesizing fluid motion paths...",
  "Generating high-definition frames...",
  "Finalizing your premium visualization..."
];

const VeoAnimator: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [loadingMsgIdx, setLoadingMsgIdx] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let interval: number;
    if (isGenerating) {
      interval = window.setInterval(() => {
        setLoadingMsgIdx((prev) => (prev + 1) % LOADING_MESSAGES.length);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      setPreviewUrl(URL.createObjectURL(selected));
      setVideoUrl(null);
      setError(null);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const generateVideo = async () => {
    if (!file) return;

    try {
      // 1. Check for API Key
      const hasKey = await (window as any).aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio.openSelectKey();
        // Proceeding assuming selection was successful as per instructions
      }

      setIsGenerating(true);
      setError(null);
      setLoadingMsgIdx(0);

      const base64Data = await fileToBase64(file);
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: 'A cinematic smooth drone shot moving slowly towards the property, elegant lighting, architectural photography style',
        image: {
          imageBytes: base64Data,
          mimeType: file.type,
        },
        config: {
          numberOfVideos: 1,
          resolution: '1080p',
          aspectRatio: aspectRatio
        }
      });

      // Poll for completion
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        try {
          operation = await ai.operations.getVideosOperation({ operation: operation });
        } catch (pollErr: any) {
          if (pollErr.message?.includes("Requested entity was not found")) {
            await (window as any).aistudio.openSelectKey();
            throw new Error("API Key session expired. Please re-select your key.");
          }
          throw pollErr;
        }
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await response.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }

    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during generation.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <section id="ai-animator" className="py-24 bg-[#0f172a] text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-900/10 blur-[120px] rounded-full pointer-events-none"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <span className="text-[#ffd700] tracking-[0.4em] uppercase font-bold text-xs mb-4 block">Future Visualization</span>
            <h2 className="text-4xl md:text-6xl font-serif-luxury mb-8 leading-tight">
              Animate Your <br/> Future Estate
            </h2>
            <p className="text-white/60 mb-10 text-lg font-light leading-relaxed">
              Upload a still photograph of any property and our advanced AI will synthesize a cinematic 1080p drone visualization. Experience the soul of architecture before you visit.
            </p>

            <div className="space-y-6">
              <div className="flex flex-wrap gap-4 mb-8">
                <button 
                  onClick={() => setAspectRatio('16:9')}
                  className={`px-6 py-2 rounded-full border text-xs font-bold tracking-widest uppercase transition-all ${aspectRatio === '16:9' ? 'bg-[#ffd700] text-[#1a237e] border-[#ffd700]' : 'border-white/20 text-white/60 hover:border-white/40'}`}
                >
                  Landscape (16:9)
                </button>
                <button 
                  onClick={() => setAspectRatio('9:16')}
                  className={`px-6 py-2 rounded-full border text-xs font-bold tracking-widest uppercase transition-all ${aspectRatio === '9:16' ? 'bg-[#ffd700] text-[#1a237e] border-[#ffd700]' : 'border-white/20 text-white/60 hover:border-white/40'}`}
                >
                  Portrait (9:16)
                </button>
              </div>

              {!file ? (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="group cursor-pointer border-2 border-dashed border-white/20 hover:border-[#ffd700]/50 bg-white/5 rounded-2xl p-12 text-center transition-all"
                >
                  <i className="fas fa-cloud-upload-alt text-4xl text-[#ffd700] mb-4 group-hover:scale-110 transition-transform"></i>
                  <p className="text-sm font-semibold mb-2">Click to upload property photo</p>
                  <p className="text-xs text-white/40 uppercase tracking-widest">JPG, PNG up to 10MB</p>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    className="hidden" 
                    accept="image/*"
                  />
                </div>
              ) : (
                <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-black">
                  {videoUrl ? (
                    <video 
                      src={videoUrl} 
                      controls 
                      autoPlay 
                      loop 
                      className={`w-full max-h-[500px] object-contain ${aspectRatio === '9:16' ? 'aspect-[9/16]' : 'aspect-video'}`}
                    />
                  ) : (
                    <img src={previewUrl!} className="w-full max-h-[500px] object-contain opacity-50 blur-sm" />
                  )}
                  
                  {isGenerating && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm">
                      <div className="w-16 h-16 border-4 border-[#ffd700]/20 border-t-[#ffd700] rounded-full animate-spin mb-6"></div>
                      <p className="text-[#ffd700] font-bold tracking-widest uppercase text-xs mb-2">Rendering Studio</p>
                      <p className="text-white text-sm font-light italic transition-all duration-1000">
                        {LOADING_MESSAGES[loadingMsgIdx]}
                      </p>
                    </div>
                  )}

                  {!isGenerating && !videoUrl && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <button 
                        onClick={generateVideo}
                        className="gold-gradient text-[#1a237e] px-10 py-4 rounded-sm font-bold tracking-widest uppercase shadow-2xl hover:scale-105 transition-transform"
                      >
                        Begin Animation
                      </button>
                    </div>
                  )}

                  {videoUrl && !isGenerating && (
                    <div className="absolute bottom-4 right-4 flex gap-2">
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-white/10 hover:bg-white/20 backdrop-blur-md px-4 py-2 rounded text-xs font-bold transition-all"
                      >
                        New Photo
                      </button>
                      <a 
                        href={videoUrl} 
                        download="EliteEstate_Animation.mp4"
                        className="bg-[#ffd700] text-[#1a237e] px-4 py-2 rounded text-xs font-bold transition-all"
                      >
                        Download
                      </a>
                    </div>
                  )}
                </div>
              )}
              
              {error && (
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs flex items-center">
                  <i className="fas fa-exclamation-circle mr-2"></i>
                  {error}
                </div>
              )}

              <p className="text-[10px] text-white/30 italic">
                * Veo 3.1 generation requires a paid API key and typically takes 1-3 minutes. 
                <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="underline ml-1">Billing documentation</a>.
              </p>
            </div>
          </div>

          <div className="lg:w-1/2 grid grid-cols-2 gap-4">
            <div className="space-y-4 pt-12">
              <div className="h-64 rounded-xl overflow-hidden shadow-2xl">
                <img src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" />
              </div>
              <div className="h-48 rounded-xl overflow-hidden shadow-2xl">
                <img src="https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" />
              </div>
            </div>
            <div className="space-y-4">
              <div className="h-48 rounded-xl overflow-hidden shadow-2xl">
                <img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" />
              </div>
              <div className="h-64 rounded-xl overflow-hidden shadow-2xl">
                <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VeoAnimator;

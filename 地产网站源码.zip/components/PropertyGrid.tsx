
import React from 'react';
import { PROPERTIES, WHATSAPP_NUMBER } from '../constants';
import { SectionId } from '../types';

const PropertyGrid: React.FC = () => {
  return (
    <section id={SectionId.Featured} className="py-20 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-[#ffd700] font-bold tracking-[0.3em] uppercase text-xs">Curated Selection</span>
          <h2 className="text-3xl md:text-5xl font-serif-luxury text-[#1a237e] mt-4 mb-6">Featured Luxury Properties</h2>
          <div className="w-24 h-1 bg-[#ffd700] mx-auto"></div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
          {PROPERTIES.map((prop) => (
            <div key={prop.id} className="group bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="relative h-64 md:h-72 overflow-hidden">
                <img 
                  src={prop.image} 
                  alt={prop.title} 
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 left-4 bg-[#1a237e]/90 text-white text-[10px] font-bold px-3 py-1 rounded tracking-widest uppercase">
                  {prop.id}
                </div>
                <div className="absolute top-4 right-4 bg-[#ffd700] text-[#1a237e] text-[10px] font-bold px-3 py-1 rounded shadow-sm tracking-widest uppercase">
                  {prop.location}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg md:text-xl font-bold text-slate-800 mb-2">{prop.title}</h3>
                <p className="text-[#1a237e] font-serif-luxury font-bold text-xl md:text-2xl mb-4">{prop.price}</p>
                <div className="flex items-center text-slate-500 text-xs mb-6 pb-6 border-b border-gray-100 font-medium">
                  <span className="mr-4 flex items-center"><i className="fas fa-vector-square mr-2 text-[#ffd700]"></i>{prop.specs.split('|')[1]}</span>
                  <span className="flex items-center"><i className="fas fa-bed mr-2 text-[#ffd700]"></i>{prop.specs.split('|')[0]}</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <a 
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hello, I'm interested in property ${prop.id} (${prop.title}). Could you provide more details?`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg text-xs font-bold transition-colors"
                  >
                    <i className="fab fa-whatsapp mr-2"></i> WhatsApp
                  </a>
                  <button className="bg-[#1a237e] hover:bg-blue-900 text-white py-3 rounded-lg text-xs font-bold transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PropertyGrid;

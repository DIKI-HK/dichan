
import React, { useState, useEffect } from 'react';
import { SectionId } from '../types';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', id: SectionId.Home },
    { name: 'About', id: SectionId.About },
    { name: 'Services', id: SectionId.Services },
    { name: 'Properties', id: SectionId.Featured },
    { name: 'Reviews', id: SectionId.Testimonials },
    { name: 'Contact', id: SectionId.Contact },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-[#1a237e] py-4 shadow-lg' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-[#ffd700] rounded-sm flex items-center justify-center">
            <span className="text-[#1a237e] font-bold text-xl">EE</span>
          </div>
          <span className={`text-xl md:text-2xl font-serif-luxury font-bold text-white tracking-widest`}>
            ELITE ESTATE
          </span>
        </div>
        
        <div className="hidden lg:flex space-x-8">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              className="text-white/80 hover:text-[#ffd700] transition-colors text-xs font-semibold tracking-widest uppercase"
            >
              {link.name}
            </a>
          ))}
        </div>

        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="lg:hidden text-white"
        >
          <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-2xl`}></i>
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`lg:hidden fixed inset-0 bg-[#1a237e] z-40 flex flex-col items-center justify-center transition-transform duration-500 ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="space-y-8 text-center">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={() => setIsMenuOpen(false)}
              className="block text-2xl text-white hover:text-[#ffd700] font-serif-luxury"
            >
              {link.name}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

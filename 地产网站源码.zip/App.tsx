
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import WhatsAppWidget from './components/WhatsAppWidget';
import PropertyGrid from './components/PropertyGrid';
import LeadFormPopup from './components/LeadFormPopup';
import VeoAnimator from './components/VeoAnimator';
import { SectionId } from './types';
import { WHATSAPP_NUMBER } from './constants';

const App: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState<'idle' | 'loading' | 'success'>('idle');

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    
    setNewsletterStatus('loading');
    try {
      await fetch('https://formspree.io/luckily945@gmail.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail, source: 'Elite Estate Footer', recipient: 'luckily945@gmail.com' })
      });
      setNewsletterStatus('success');
      setNewsletterEmail('');
      setTimeout(() => setNewsletterStatus('idle'), 5000);
    } catch (err) {
      console.error(err);
      setNewsletterStatus('idle');
    }
  };

  return (
    <div className="min-h-screen relative">
      <Navbar />
      <LeadFormPopup />
      <WhatsAppWidget />

      {/* Hero Section */}
      <section id={SectionId.Home} className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/50 z-10"></div>
        <div 
          className="absolute inset-0 hero-parallax z-0 scale-105" 
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=100&w=2000')` }}
        ></div>
        <div className="container mx-auto px-6 relative z-20 text-center">
          <span className="text-[#ffd700] tracking-[0.6em] uppercase font-bold mb-4 block animate-fade-in text-xs md:text-sm">Ghana's Premier Real Estate Experience</span>
          <h1 className="text-4xl md:text-8xl font-serif-luxury text-white font-bold mb-8 animate-fade-in-up leading-tight">
            Discover Accra's <br className="hidden md:block"/> Finest Living
          </h1>
          <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-12 leading-relaxed font-light">
            Defining luxury in the heart of West Africa. We offer bespoke investment strategies and exclusive access to Ghana's most prestigious postcodes.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <a href={`#${SectionId.Featured}`} className="w-full sm:w-auto gold-gradient px-12 py-4 rounded-sm text-[#1a237e] font-bold text-sm tracking-widest uppercase hover:scale-105 transition-all shadow-xl">
              View Properties
            </a>
            <a 
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hello, I am interested in premium real estate in Accra and would like a personal consultation.`}
              target="_blank"
              className="w-full sm:w-auto bg-white/10 backdrop-blur-md border border-white/30 px-12 py-4 rounded-sm text-white font-bold text-sm tracking-widest uppercase hover:bg-white/20 transition-all"
            >
              Consult with Us
            </a>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce text-white/50">
          <i className="fas fa-chevron-down text-2xl"></i>
        </div>
      </section>

      {/* About Section */}
      <section id={SectionId.About} className="py-24 bg-[#f8fafc]">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2 relative">
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-[#ffd700]/20 z-0"></div>
              <img 
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600" 
                alt="Elite Real Estate Architecture" 
                className="rounded-lg shadow-2xl relative z-10 w-full object-cover aspect-[4/3] grayscale-[10%] hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute -bottom-10 -right-10 bg-[#1a237e] text-white p-8 rounded-lg shadow-xl hidden md:block z-20 border border-white/10">
                <p className="text-4xl font-bold mb-1 font-serif-luxury text-[#ffd700]">15+</p>
                <p className="text-[10px] uppercase tracking-[0.2em] font-semibold">Years in Accra Market</p>
              </div>
            </div>
            <div className="lg:w-1/2">
              <h2 className="text-4xl md:text-5xl font-serif-luxury text-[#1a237e] mb-8 leading-tight">Excellence in the <br/>Ghanaian Market</h2>
              <p className="text-slate-600 mb-8 leading-relaxed font-light text-lg">
                Elite Estate is Ghana's leading high-end real estate agency. From the vibrant streets of Labone to the serene avenues of Cantonments, we curate the finest portfolio for local and diaspora investors.
              </p>
              <ul className="grid sm:grid-cols-2 gap-6 mb-10">
                {[
                  'Accra\'s Top 1% Agency',
                  'Exclusive Prime Land Bank',
                  'Diaspora Investment Concierge',
                  'Bespoke Legal & Title Search'
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center text-slate-700 font-semibold text-sm">
                    <i className="fas fa-check-circle text-[#ffd700] mr-3 text-lg"></i>
                    {item}
                  </li>
                ))}
              </ul>
              <button className="border-b-2 border-[#1a237e] text-[#1a237e] pb-1 font-bold tracking-widest uppercase text-xs hover:text-[#ffd700] hover:border-[#ffd700] transition-all">
                Learn our local story <i className="fas fa-arrow-right ml-2 text-[10px]"></i>
              </button>
            </div>
          </div>
        </div>
      </section>

      <PropertyGrid />

      {/* AI Property Animator Section */}
      <VeoAnimator />

      {/* Services Section */}
      <section id={SectionId.Services} className="py-24 bg-[#1a237e] text-white">
        <div className="container mx-auto px-6 text-center">
          <div className="mb-20">
            <h2 className="text-3xl md:text-5xl font-serif-luxury text-[#ffd700] mb-6">Bespoke Solutions</h2>
            <p className="text-white/50 tracking-widest uppercase text-xs">Unmatched Expertise in West African Real Estate</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            {[
              { icon: 'fa-chart-line', title: 'Market Intelligence', desc: 'Real-time data analysis of Accra and regional property value trends.' },
              { icon: 'fa-handshake', title: 'Diaspora Services', desc: 'Tailored property management and acquisition for Ghanaians abroad.' },
              { icon: 'fa-briefcase', title: 'Commercial Advisory', desc: 'Focused on grade-A office space and retail hubs in the Greater Accra region.' }
            ].map((s, i) => (
              <div key={i} className="bg-white/5 border border-white/10 p-10 rounded-xl hover:bg-white/10 transition-all text-left">
                <i className={`fas ${s.icon} text-3xl text-[#ffd700] mb-8`}></i>
                <h3 className="text-2xl font-serif-luxury font-bold mb-4">{s.title}</h3>
                <p className="text-white/60 leading-relaxed mb-8 font-light">{s.desc}</p>
                <a 
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=I am interested in ${s.title} services for my project in Ghana.`}
                  className="text-[#ffd700] font-bold text-xs uppercase tracking-[0.2em] hover:brightness-125 inline-flex items-center"
                >
                  Discover More <i className="fas fa-plus ml-3 text-[10px]"></i>
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id={SectionId.Testimonials} className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <i className="fas fa-quote-left text-5xl text-[#ffd700]/20 mb-8"></i>
            <h2 className="text-3xl md:text-4xl font-serif-luxury text-[#1a237e] mb-12 italic">The Choice of the Discerning</h2>
            <div className="bg-gray-50 p-8 md:p-16 rounded-3xl border border-gray-100 italic text-xl md:text-2xl text-slate-700 leading-relaxed font-light shadow-sm">
              "Elite Estate's deep understanding of the Accra luxury market is unparalleled. They navigated the land title process in Cantonments with absolute transparency and secured a home that far exceeded my expectations."
            </div>
            <div className="mt-10">
              <p className="font-bold text-[#1a237e] text-lg uppercase tracking-widest">Mr. David Ofori-Atta</p>
              <p className="text-xs text-slate-400 font-semibold mt-1">Founder, West Coast Capital</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-white pt-24 pb-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-8">
                <div className="w-10 h-10 bg-[#ffd700] rounded-sm flex items-center justify-center">
                  <span className="text-[#1a237e] font-bold text-xl">EE</span>
                </div>
                <span className="text-2xl font-serif-luxury font-bold tracking-[0.3em]">ELITE ESTATE</span>
              </div>
              <p className="text-white/40 max-w-sm mb-10 leading-relaxed font-light">
                Elite Estate Ghana (License: GREDA-12345). Committed to integrity and elevating professionalism in the West African real estate sector.
              </p>
              <div className="flex space-x-6">
                {['facebook', 'instagram', 'linkedin', 'twitter'].map(s => (
                  <a key={s} href="#" className="text-white/30 hover:text-[#ffd700] transition-all text-lg">
                    <i className={`fab fa-${s}`}></i>
                  </a>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-bold mb-8 text-[#ffd700] uppercase tracking-widest">Local Insights</h4>
              <ul className="space-y-4 text-white/50 text-sm font-medium">
                {['East Legon Trends', 'Airport Residential Living', 'Cantonments Growth', 'Mortgage Partners', 'Ghana Property Law'].map(l => (
                  <li key={l}><a href="#" className="hover:text-white transition-colors">{l}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-bold mb-8 text-[#ffd700] uppercase tracking-widest">Join the Circle</h4>
              <p className="text-xs text-white/40 mb-6 font-light">Stay updated on Accra's most exclusive off-market listings.</p>
              
              <form onSubmit={handleNewsletterSubmit} className="relative group">
                <input 
                  type="email" 
                  placeholder={newsletterStatus === 'success' ? 'Thank you!' : 'Your Email'} 
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  disabled={newsletterStatus !== 'idle'}
                  className={`w-full bg-white/5 border border-white/10 rounded-lg py-4 px-6 text-sm focus:outline-none focus:border-[#ffd700] transition-all ${newsletterStatus === 'success' ? 'border-green-500 text-green-500' : ''}`}
                />
                <button 
                  type="submit"
                  disabled={newsletterStatus !== 'idle'}
                  className="absolute right-3 top-2 bottom-2 bg-[#ffd700] text-[#1a237e] px-4 rounded hover:brightness-110 transition-all flex items-center justify-center min-w-[40px]"
                >
                  {newsletterStatus === 'loading' ? (
                    <i className="fas fa-circle-notch animate-spin text-xs"></i>
                  ) : newsletterStatus === 'success' ? (
                    <i className="fas fa-check text-xs"></i>
                  ) : (
                    <i className="fas fa-paper-plane text-xs"></i>
                  )}
                </button>
              </form>
              <p className="text-[9px] text-white/20 mt-3 uppercase tracking-widest">Routing via Formspree to luckily945@gmail.com</p>
            </div>
          </div>
          <div className="border-t border-white/5 pt-12 text-center text-white/20 text-[10px] tracking-[0.3em] uppercase font-bold">
            <p>&copy; 2024 Elite Estate Ghana. Premium Marketing for West Africa.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;

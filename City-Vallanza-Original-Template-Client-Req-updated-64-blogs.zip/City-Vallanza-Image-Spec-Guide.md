# City Vallanza 图片出图清单

## 核心统一规格

- 首页 Hero 主视觉：`3840 x 2160`，比例 `16:9`
- 内页头图 Banner：`3200 x 1600`，比例 `2:1`
- 横向图文模块主图：`2400 x 1440`，比例 `5:3`
- 房源卡片图：`2400 x 1530`，比例 `16:10.2`
- About 区域说明图：`2400 x 1800`，比例 `4:3`
- 放大查看原图：建议至少 `3000px` 宽

## 页面与区域说明

### HOME

- 首页 Hero 主视觉背景图
  - 推荐：`3840 x 2160`
  - 说明：全屏铺满，适合最高清的主视觉图

- About 区域左侧图片
  - 推荐：`2400 x 1800`
  - 说明：适合项目总览图、鸟瞰图、生活方式总览图

- Featured Properties 房源卡图
  - 推荐：`2400 x 1530`
  - 说明：建议和 CATALOG 卡片统一

### CATALOG

- 页面头图 Banner
  - 推荐：`3200 x 1600`

- 房源卡图片
  - 推荐：`2400 x 1530`

- Explore More 页面卡片图
  - 推荐：`2400 x 1530`

### NEWS

- 页面头图 Banner
  - 推荐：`3200 x 1600`

- 新闻横向卡片左图
  - 推荐：`2400 x 1440`
  - 说明：和 PROJECT / COMPANY 横向图文模块统一

### COMPANY

- 页面头图 Banner（如果未来恢复）
  - 推荐：`3200 x 1600`

- Introduction 左图
  - 推荐：`2400 x 1440`

- Philosophy 1 / 2 / 3 图片
  - 推荐：`2400 x 1440`

- 纯图片网格模式
  - 推荐：`2560 x 1440` 或 `3200 x 1800`

### PROJECT

- 每个模块左侧轮播图
  - 推荐：`2400 x 1440`

- 点击放大查看原图
  - 推荐：至少 `3000px` 宽

### CONTACT

- 页面头图 Banner
  - 推荐：`3200 x 1600`

### UNIT DETAIL

- 户型详情页 Hero 图
  - 推荐：`3200 x 1600`

- Plan Perspectives 轮播图
  - 推荐：`2400 x 1440`

- Amenities 小轮播图
  - 推荐：`2200 x 1320` 或 `2400 x 1440`

### STORY DISPLAY / CONTENT PAGE / FLOOR PLAN HIGHLIGHTS

- Story Display 头图
  - 推荐：`3200 x 1600`

- Story Display 每条图文模块图片
  - 推荐：`2400 x 1440`

- Content Page 正文配图
  - 推荐：`2400 x 1350` 或 `2400 x 1600`

- Floor Plan Highlights 高亮卡片图
  - 推荐：`2000 x 1200`

## 当前默认素材尺寸

- `city-vallanza-hero-4k.jpg`：`3840 x 2160`
- `city-vallanza-masterplan.jpg`：`1920 x 1080`
- `city-vallanza-aerial.jpg`：`1877 x 1920`
- `city-vallanza-villas-dusk.jpg`：`1920 x 1217`
- `city-vallanza-resort-pool.jpg`：`1920 x 1129`
- `city-vallanza-elite-villa.jpg`：`1920 x 1279`
- `city-vallanza-garage.jpg`：`1920 x 1811`
- `city-vallanza-hero.jpg`：`1920 x 1004`

## 出图规则

- 格式优先：`JPG`
- 压缩质量建议：`80-85`
- 重要主体放在画面中间 `60%` 安全区域
- 横向模块不要再用偏竖图，会被裁切得很重
- 同一页面同一模块尽量统一比例
- Logo 优先用 `SVG`

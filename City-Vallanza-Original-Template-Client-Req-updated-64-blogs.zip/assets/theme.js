class NavbarController {
  constructor() {
    this.nav = document.getElementById('navbar');
    this.mobileMenu = document.getElementById('mobile-menu');
    this.mobileMenuBtn = document.getElementById('mobile-menu-btn');
    this.closeMenuBtn = document.getElementById('close-menu-btn');
    this.mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
    this.navLinks = this.nav ? this.nav.querySelectorAll('.cv-navbar-link') : [];
    
    if (!this.nav) return;
    
    this.init();
  }

  init() {
    if (this.nav.dataset.controllerBound === 'true') {
      this.updateCurrentLink();
      this.handleScroll();
      return;
    }

    this.nav.dataset.controllerBound = 'true';
    this.handleScroll = this.handleScroll.bind(this);
    this.toggleMenu = this.toggleMenu.bind(this);
    this.handleEscape = this.handleEscape.bind(this);

    window.addEventListener('scroll', this.handleScroll, { passive: true });
    document.addEventListener('keydown', this.handleEscape);
    
    if (this.mobileMenuBtn) this.mobileMenuBtn.addEventListener('click', () => this.toggleMenu());
    if (this.closeMenuBtn) this.closeMenuBtn.addEventListener('click', () => this.toggleMenu());
    
    this.mobileNavLinks.forEach(link => {
      link.addEventListener('click', () => this.toggleMenu(true));
    });
    
    this.updateCurrentLink();
    this.handleScroll();
  }

  handleEscape(event) {
    if (event.key !== 'Escape') return;
    if (!this.mobileMenuBtn) return;
    const isExpanded = this.mobileMenuBtn.getAttribute('aria-expanded') === 'true';
    if (isExpanded) this.toggleMenu(true);
  }

  handleScroll() {
    const isScrolled = window.scrollY > 12;
    this.nav.classList.toggle('is-scrolled', isScrolled);
  }

  updateCurrentLink() {
    const currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
    this.navLinks.forEach((link) => {
      const href = link.getAttribute('href');
      if (!href) return;

      let isCurrent = false;
      if (href === '#home') {
        isCurrent = currentPath === '/';
      } else if (href.startsWith('/')) {
        const normalizedHref = href.replace(/\/+$/, '') || '/';
        isCurrent = normalizedHref === currentPath;
      }
      link.classList.toggle('is-current', isCurrent);
    });
  }

  toggleMenu(forceClose = false) {
    if (!this.mobileMenu || !this.mobileMenuBtn) return;
    
    const isExpanded = this.mobileMenuBtn.getAttribute('aria-expanded') === 'true';
    const shouldOpen = forceClose ? false : !isExpanded;
    this.mobileMenuBtn.setAttribute('aria-expanded', String(shouldOpen));
    
    this.mobileMenu.classList.toggle('translate-x-full', !shouldOpen);
    this.mobileMenu.classList.toggle('translate-x-0', shouldOpen);
    this.mobileMenu.setAttribute('aria-hidden', shouldOpen ? 'false' : 'true');
    document.body.classList.toggle('overflow-hidden', shouldOpen);
  }
}

class PrivacyBannerController {
  constructor() {
    this.banner = document.getElementById('privacy-consent');
    this.acceptBtn = document.getElementById('accept-privacy');
    
    if (!this.banner || !this.acceptBtn) return;
    
    this.init();
  }

  init() {
    if (this.banner.dataset.controllerBound === 'true') return;
    this.banner.dataset.controllerBound = 'true';

    if (!localStorage.getItem('privacyAccepted')) {
      this.banner.classList.remove('hidden');
    }

    this.acceptBtn.addEventListener('click', () => {
      localStorage.setItem('privacyAccepted', 'true');
      this.banner.classList.add('hidden');
    });
  }
}

class TestimonialsCarouselController {
  constructor() {
    this.root = document.querySelector('[data-testimonial-slider]');
    if (!this.root) return;

    this.slides = Array.from(this.root.querySelectorAll('[data-testimonial-slide]'));
    this.dots = Array.from(this.root.querySelectorAll('[data-testimonial-dot]'));
    this.currentIndex = 0;
    this.intervalId = null;
    this.autoplaySeconds = Number(this.root.dataset.autoplaySeconds || 5);

    if (this.slides.length < 2) return;
    this.init();
  }

  init() {
    if (this.root.dataset.carouselBound === 'true') return;
    this.root.dataset.carouselBound = 'true';

    this.dots.forEach((dot) => {
      dot.addEventListener('click', () => {
        const nextIndex = Number(dot.dataset.index || 0);
        this.goTo(nextIndex);
        this.restartAutoplay();
      });
    });

    this.startAutoplay();
  }

  startAutoplay() {
    this.intervalId = window.setInterval(() => {
      const nextIndex = (this.currentIndex + 1) % this.slides.length;
      this.goTo(nextIndex);
    }, Math.max(3, this.autoplaySeconds) * 1000);
  }

  restartAutoplay() {
    if (this.intervalId) {
      window.clearInterval(this.intervalId);
    }
    this.startAutoplay();
  }

  goTo(nextIndex) {
    this.slides.forEach((slide, index) => {
      slide.classList.toggle('hidden', index !== nextIndex);
    });
    this.dots.forEach((dot, index) => {
      dot.classList.toggle('bg-[#1a237e]', index === nextIndex);
      dot.classList.toggle('bg-transparent', index !== nextIndex);
    });
    this.currentIndex = nextIndex;
  }
}

class ChatWidgetController {
  constructor() {
    this.button = document.querySelector('[data-chat-widget="whatsapp-fallback"]');
    if (!this.button) return;
    this.init();
  }

  init() {
    if (this.button.dataset.controllerBound === 'true') return;
    this.button.dataset.controllerBound = 'true';

    this.button.addEventListener('click', (event) => {
      const chatbot =
        window.CVChatbot ||
        window.CityVallanzaChatbot ||
        window.AIChatbot ||
        null;

      if (chatbot && typeof chatbot.open === 'function') {
        event.preventDefault();
        chatbot.open({
          source: 'floating_chat_widget',
          fallbackUrl: this.button.href
        });
        return;
      }

      window.dispatchEvent(
        new CustomEvent('cv:chat-widget-click', {
          detail: {
            source: 'floating_chat_widget',
            fallbackUrl: this.button.href
          }
        })
      );
    });
  }
}

class LeadFormController {
  constructor() {
    this.newsForm = document.getElementById('news-subscribe-form');
    if (!this.newsForm) return;
    this.init();
  }

  init() {
    if (this.newsForm.dataset.backgroundNotifyBound === 'true') return;
    this.newsForm.dataset.backgroundNotifyBound = 'true';
    this.bindNewsForm(this.newsForm);
  }

  bindNewsForm(form) {
    form.addEventListener('submit', () => {
      if (form.dataset.backgroundNotifySubmitted === 'true') return;

      const targetForm = document.getElementById('news-subscribe-email-notify-form');
      const sourceEmail = form.querySelector('[name="contact[email]"]');
      const targetEmail = targetForm ? targetForm.querySelector('[data-news-notify-email]') : null;
      const targetBody = targetForm ? targetForm.querySelector('[data-news-notify-body]') : null;

      if (!targetForm || !sourceEmail || !targetEmail || !targetBody) return;

      const email = sourceEmail.value.trim();
      if (!email) return;

      form.dataset.backgroundNotifySubmitted = 'true';
      targetForm.setAttribute('target', 'cv-news-subscribe-email-frame');
      targetEmail.value = email;
      targetBody.value = [
        'A new newsletter subscription was received on City Vallanza.',
        `Email: ${email}`,
        `Source page: ${window.location.href}`,
        `Submitted at: ${new Date().toISOString()}`
      ].join('\n');

      if (typeof targetForm.requestSubmit === 'function') {
        targetForm.requestSubmit();
        return;
      }

      targetForm.submit();
    }, { capture: true });
  }
}

class UnitGalleryController {
  constructor() {
    this.galleries = Array.from(document.querySelectorAll('[data-unit-gallery]'));
    this.lightbox = document.querySelector('[data-unit-lightbox]');
    this.lightboxImage = this.lightbox ? this.lightbox.querySelector('[data-unit-lightbox-image]') : null;
    this.closeBtn = this.lightbox ? this.lightbox.querySelector('[data-unit-lightbox-close]') : null;

    if (!this.galleries.length) return;
    this.init();
  }

  init() {
    this.galleries.forEach((gallery) => this.bindGallery(gallery));

    if (!this.lightbox) return;

    if (this.closeBtn) {
      this.closeBtn.addEventListener('click', () => this.closeLightbox());
    }

    this.lightbox.addEventListener('click', (event) => {
      if (event.target === this.lightbox) {
        this.closeLightbox();
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        this.closeLightbox();
      }
    });
  }

  bindGallery(gallery) {
    if (gallery.dataset.galleryBound === 'true') return;
    gallery.dataset.galleryBound = 'true';

    const slides = Array.from(gallery.querySelectorAll('[data-gallery-slide]'));
    const dots = Array.from(gallery.querySelectorAll('[data-gallery-dot]'));
    const prevBtn = gallery.querySelector('[data-gallery-prev]');
    const nextBtn = gallery.querySelector('[data-gallery-next]');
    const autoplaySeconds = Number(gallery.dataset.autoplaySeconds || 0);

    if (!slides.length) return;

    let currentIndex = 0;
    let timer = null;
    let touchStartX = 0;
    let touchStartY = 0;
    let isTouchTracking = false;

    const showSlide = (nextIndex) => {
      const normalized = ((nextIndex % slides.length) + slides.length) % slides.length;
      slides.forEach((slide, index) => {
        slide.classList.toggle('is-hidden', index !== normalized);
      });
      dots.forEach((dot, index) => {
        dot.classList.toggle('is-active', index === normalized);
      });
      currentIndex = normalized;
    };

    const startAutoplay = () => {
      if (autoplaySeconds < 2 || slides.length < 2) return;
      if (timer) window.clearInterval(timer);
      timer = window.setInterval(() => {
        showSlide(currentIndex + 1);
      }, autoplaySeconds * 1000);
    };

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        showSlide(currentIndex - 1);
        startAutoplay();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        showSlide(currentIndex + 1);
        startAutoplay();
      });
    }

    dots.forEach((dot) => {
      dot.addEventListener('click', () => {
        const index = Number(dot.dataset.index || 0);
        showSlide(index);
        startAutoplay();
      });
    });

    gallery.addEventListener('touchstart', (event) => {
      if (!event.touches || event.touches.length !== 1) return;
      isTouchTracking = true;
      touchStartX = event.touches[0].clientX;
      touchStartY = event.touches[0].clientY;
      if (timer) window.clearInterval(timer);
    }, { passive: true });

    gallery.addEventListener('touchend', (event) => {
      if (!isTouchTracking || !event.changedTouches || event.changedTouches.length !== 1) {
        startAutoplay();
        return;
      }

      const endX = event.changedTouches[0].clientX;
      const endY = event.changedTouches[0].clientY;
      const deltaX = endX - touchStartX;
      const deltaY = endY - touchStartY;

      if (Math.abs(deltaX) > 42 && Math.abs(deltaX) > Math.abs(deltaY)) {
        showSlide(currentIndex + (deltaX > 0 ? -1 : 1));
      }

      isTouchTracking = false;
      startAutoplay();
    }, { passive: true });

    slides.forEach((slide) => {
      slide.addEventListener('click', () => {
        this.openLightbox(
          slide.dataset.fullSrc || '',
          slide.dataset.fullAlt || ''
        );
      });
    });

    showSlide(0);
    startAutoplay();
  }

  openLightbox(src, alt) {
    if (!this.lightbox || !this.lightboxImage || !src) return;
    this.lightboxImage.src = src;
    this.lightboxImage.alt = alt || 'Unit image';
    this.lightbox.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
  }

  closeLightbox() {
    if (!this.lightbox || !this.lightboxImage) return;
    this.lightbox.classList.add('hidden');
    this.lightboxImage.src = '';
    this.lightboxImage.alt = '';
    document.body.classList.remove('overflow-hidden');
  }
}

class GlobalUIController {
  constructor() {
    this.revealSelector = [
      'main section:not(#home)',
      '.cv-card',
      '.cv-news-card',
      '.cv-story-row',
      '.cv-unit-panel',
      '.cv-contact-card',
      '.cv-service-card',
      '[data-property-item] > .group'
    ].join(',');
    this.init();
  }

  init() {
    if (!window.__cvGlobalListenersBound) {
      this.bindSmoothScroll();
      this.bindPageTransitions();
      window.__cvGlobalListenersBound = true;
    }
    this.applyInteractiveClasses();
    this.bindTouchFeedback();
    this.setupLazyImageState();
    this.setupReveal();
    this.markPageReady();
  }

  markPageReady() {
    window.requestAnimationFrame(() => {
      document.body.classList.add('cv-page-ready');
    });
  }

  applyInteractiveClasses() {
    const selectors = [
      '.cv-navbar-link',
      '.cv-catalog-tab',
      '.cv-news-card',
      '.cv-story-row',
      '.cv-unit-panel',
      '.cv-contact-card',
      '.cv-service-card',
      '[data-property-item] > .group',
      '.cv-btn',
      'footer .flex.space-x-6 a',
      '.cv-contact-submit-btn',
      '.cv-news-subscribe-button',
      '#mobile-menu-btn',
      '#close-menu-btn',
      '[data-gallery-prev]',
      '[data-gallery-next]',
      'a[class*="px-"][class*="py-"]'
    ];
    document.querySelectorAll(selectors.join(',')).forEach((element) => {
      element.classList.add('cv-interactive');
    });
  }

  bindTouchFeedback() {
    if (window.__cvTouchFeedbackBound) return;
    window.__cvTouchFeedbackBound = true;

    document.addEventListener('touchstart', (event) => {
      const target = event.target.closest('.cv-interactive');
      if (!target) return;
      target.classList.add('is-pressed');
    }, { passive: true });

    const clearPressedState = () => {
      document.querySelectorAll('.cv-interactive.is-pressed').forEach((element) => {
        element.classList.remove('is-pressed');
      });
    };

    document.addEventListener('touchend', clearPressedState, { passive: true });
    document.addEventListener('touchcancel', clearPressedState, { passive: true });
  }

  setupLazyImageState() {
    const images = Array.from(document.querySelectorAll('img[loading="lazy"]'));
    images.forEach((img) => {
      if (img.dataset.cvLazyBound === 'true') return;
      img.dataset.cvLazyBound = 'true';
      img.classList.add('cv-lazy-fade');

      const markLoaded = () => img.classList.add('is-loaded');
      if (img.complete) {
        markLoaded();
      } else {
        img.addEventListener('load', markLoaded, { once: true });
        img.addEventListener('error', markLoaded, { once: true });
      }
    });
  }

  bindSmoothScroll() {
    document.addEventListener('click', (event) => {
      const link = event.target.closest('a[href^="#"]');
      if (!link) return;

      const href = link.getAttribute('href');
      if (!href || href === '#') return;

      const target = document.querySelector(href);
      if (!target) return;

      event.preventDefault();
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    });
  }

  bindPageTransitions() {
    document.addEventListener('click', (event) => {
      const link = event.target.closest('a[href]');
      if (!link) return;
      if (link.target === '_blank' || link.hasAttribute('download')) return;
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

      const href = link.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
      if (href.startsWith('http') && !href.includes(window.location.host)) return;

      document.body.classList.add('cv-page-leaving');
    });
  }

  setupReveal() {
    const revealTargets = Array.from(document.querySelectorAll(this.revealSelector));
    if (!revealTargets.length) return;

    if (!('IntersectionObserver' in window)) {
      revealTargets.forEach((target) => target.classList.add('is-inview'));
      return;
    }

    if (!window.__cvRevealObserver) {
      window.__cvRevealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-inview');
          observer.unobserve(entry.target);
        });
      }, {
        root: null,
        threshold: 0.14,
        rootMargin: '0px 0px -12% 0px'
      });
    }

    revealTargets.forEach((target, index) => {
      if (target.dataset.cvRevealBound === 'true') return;
      target.dataset.cvRevealBound = 'true';
      target.classList.add('cv-reveal');
      target.style.setProperty('--cv-reveal-delay', `${Math.min(index * 36, 260)}ms`);
      window.__cvRevealObserver.observe(target);
    });
  }
}

const initializeThemeControllers = () => {
  new NavbarController();
  new PrivacyBannerController();
  new TestimonialsCarouselController();
  new ChatWidgetController();
  new LeadFormController();
  new UnitGalleryController();
  new GlobalUIController();
};

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', initializeThemeControllers);

// Re-initialize for Shopify Theme Editor events
document.addEventListener('shopify:section:load', initializeThemeControllers);

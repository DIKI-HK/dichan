# City Vallanza SEO Title & Meta Description Templates

Use these values in Shopify page editor:
- `Search engine listing > Page title`
- `Search engine listing > Meta description`

## Copy-Paste Templates

### about-project
SEO title:
`About the Project | City Vallanza`

Meta description:
`Discover City Vallanza, a flagship luxury villa community on 9.39 acres in Accra's Airport Residential Area, developed by Goldsyn Group Ltd.`

### about-company
SEO title:
`About Goldsyn Group | City Vallanza`

Meta description:
`Learn about Goldsyn Group Ltd, established in 2025 by leading developers, bringing global real estate expertise to Ghana through City Vallanza.`

### catalog
SEO title:
`Villa Catalog | City Vallanza`

Meta description:
`Explore Elite, Signature, and Imperial Vallanza villa collections with floor plans, lifestyle features, and investment-ready residences in Accra.`

### news
SEO title:
`News & Updates | City Vallanza`

Meta description:
`Read the latest City Vallanza construction milestones, launch updates, and market insights from the sales and development team in Accra, Ghana.`

### contact
SEO title:
`Contact Sales Office | City Vallanza`

Meta description:
`Contact the City Vallanza sales office in Airport City, Accra for brochures, private consultations, site visits, and unit availability details.`

### elite-vallanza
SEO title:
`Elite Vallanza Villa | City Vallanza`

Meta description:
`Explore Elite Vallanza floor plans, key features, and lifestyle amenities designed for refined family living in Accra's Airport Residential Area.`

### signature-vallanza
SEO title:
`Signature Vallanza Villa | City Vallanza`

Meta description:
`View Signature Vallanza specifications, plan galleries, and design highlights combining prestige, functionality, and premium private-villa living.`

### imperial-vallanza
SEO title:
`Imperial Vallanza Villa | City Vallanza`

Meta description:
`Discover Imperial Vallanza, the largest and most prestigious residence, with expansive layouts, private retreat spaces, and elevated luxury features.`

### additional-unit
SEO title:
`Unit Details | City Vallanza`

Meta description:
`View detailed specifications, floor plans, amenities, and lifestyle features for City Vallanza villa residences in Accra, Ghana.`

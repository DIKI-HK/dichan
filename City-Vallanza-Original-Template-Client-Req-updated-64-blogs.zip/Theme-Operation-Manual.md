# City Vallanza Shopify Theme Operation Manual (EN + 中文)

Applies to: `City-Vallanza-Original-Template-Client-Req.zip`  
Last updated: `2026-03-31`

---

## ENGLISH VERSION

### 1. Scope
This manual covers all Shopify-side actions required after uploading the theme, including:
1. Required page creation and template assignment
2. Navigation link consistency
3. Content/image updates in the Theme Editor
4. Contact/news form routing
5. WhatsApp and map behavior
6. 404 troubleshooting

### 2. Critical Pre-Launch Flow
1. `Online Store > Themes > Add theme > Upload zip file`
2. Upload `City-Vallanza-Original-Template-Client-Req.zip`
3. Do not publish immediately; click `Customize` first
4. Complete all required page/template mapping in Section 3
5. Run the checklist in Section 11, then publish

### 3. Required Pages (Must Be Created)
If any handle below is missing or mismatched, users will see `404 Not Found`.

| Page Purpose | Required Handle | Template (Theme template dropdown) | URL |
|---|---|---|---|
| About the Project | `about-project` | `about-project` | `/pages/about-project` |
| Catalog | `catalog` | `catalog` | `/pages/catalog` |
| News | `news` | `news` | `/pages/news` |
| About the Company | `about-company` | `about-company` | `/pages/about-company` |
| Contact | `contact` | `contact` | `/pages/contact` |
| Elite Unit Detail | `elite-vallanza` | `elite-vallanza` | `/pages/elite-vallanza` |
| Signature Unit Detail | `signature-vallanza` | `signature-vallanza` | `/pages/signature-vallanza` |
| Imperial Unit Detail | `imperial-vallanza` | `imperial-vallanza` | `/pages/imperial-vallanza` |
| Future Unit Template Sample | `additional-unit` | `unit-detail` | `/pages/additional-unit` |

How to create each page:
1. Go to `Online Store > Pages > Add page`
2. Enter title
3. Edit URL handle to exactly match above
4. In `Theme template`, choose the matching template
5. Save

### 4. Navigation Behavior (Important)
Header and footer links are hard-linked to fixed URLs in this version.  
That means page handles must stay consistent with Section 3.

If you change a page handle later, do one of the following:
1. Revert handle back to original, or
2. Ask developer to update theme links, or
3. Create a Shopify URL redirect from old URL to new URL

### 5. Theme Settings Configuration
Go to: `Online Store > Themes > Customize > Theme settings`

#### 5.1 Business Information
Fill/verify:
1. `Favicon image`
2. `Business Name`
3. `Contact Phone (WhatsApp)` (use international format, e.g. `+233 (0) 595 755 557`)
4. `Website`
5. `Contact Email`
6. `Business Address`
7. `Business Google Map Link`

Where these values are used:
1. Footer contact area
2. Contact page details
3. WhatsApp CTA generation
4. Map outbound link

#### 5.2 Social Media
Fill/verify:
1. `Facebook`
2. `Instagram`
3. `TikTok` (stored under the TikTok-labeled field)
4. `YouTube`

Used in footer icon row only.

#### 5.3 Brand Colors (VIS)
Set:
1. `Dark Jungle Green`
2. `Brunswick Green`
3. `Pearl`
4. `Pale Copper`

### 6. Page Content Editing Guide
Go to: `Online Store > Themes > Customize`

#### 6.1 Home page
Sections to maintain:
1. `Hero`
2. `About`
3. `Featured Properties`
4. `Services`
5. `Testimonials`

Key notes:
1. Hero CTA usually points to `/pages/catalog` and `/pages/contact`
2. Property cards should point to each unit detail page
3. Services `Discover More` points to `/pages/about-company`

#### 6.2 Catalog page
Template: `catalog`  
Section: `Featured Properties`

Per property block, maintain:
1. Unit title and specs
2. Image
3. `Details Link` (must point to correct unit page)

#### 6.3 Unit detail pages (Elite / Signature / Imperial / future units)
Templates: `elite-vallanza`, `signature-vallanza`, `imperial-vallanza`, `unit-detail`

Section: `Unit Detail Template`

Maintain:
1. Hero image and unit name
2. Top spec row (icons + text)
3. Plan gallery images (carousel + click zoom)
4. Amenities items
5. Amenities gallery
6. Feature text blocks
7. Bottom CTA link (normally `/pages/contact`)

#### 6.4 About the Project / About the Company
Templates: `about-project`, `about-company`

Section: `About Structured Page`

About Project recommended structure:
1. Project introduction
2. Feature 1
3. Feature 2
4. Feature 3
5. Map block enabled (`Show Project Address Map`)

About Company recommended structure:
1. Company introduction
2. Philosophy 1
3. Philosophy 2
4. Philosophy 3
5. Map block can be disabled if not needed

#### 6.5 News page
Template: `news`  
Section: `News Cards Page`

Maintain:
1. Hero image/title/intro
2. 3 news cards by default (image, title, 100-150 word summary, date, location)
3. Subscription text and EDM contact email

No `Read More` button in this layout.

#### 6.6 Contact page
Template: `contact`  
Section: `Contact Form Page`

Maintain:
1. Hero image/title/description
2. Operating info text
3. Map embed URL
4. Lead form copy
5. `Unit Interest` dropdown:
   - label
   - placeholder
   - options (comma-separated)

### 7. Where Form Data Goes
#### 7.1 Contact form (`form 'contact'`)
Data goes through Shopify contact flow.

Recommended admin setup:
1. `Settings > General` set correct store email
2. `Settings > Notifications` set sender email/domain authentication

#### 7.2 News subscription (`form 'customer'`)
Submitted emails are sent to Shopify customer subscription flow with tags:
1. `news-edm`
2. `newsletter`

Use `Customers` in Shopify admin for follow-up operations.

### 8. WhatsApp and Floating Chat
Phone source: `Theme settings > Business Information > Contact Phone (WhatsApp)`

Behavior:
1. Floating button and WhatsApp CTAs use this number
2. If custom chatbot script exists, chatbot may open first
3. If no chatbot hook exists, it falls back to WhatsApp direct chat

### 9. Google Map Language
Map labels may localize by user/browser region.  
To prefer English:
1. Use embed/map links containing `hl=en`
2. Keep external `View on Google Maps` link for full map access

### 10. Standard 404 Troubleshooting
If a click opens a 404 page:
1. Copy the failed URL
2. Check whether corresponding page exists in `Online Store > Pages`
3. Verify page handle matches URL exactly
4. Verify `Theme template` is assigned correctly
5. Save and retest in incognito mode

Example:
`/pages/about-company` 404 usually means:
1. no page with handle `about-company`, or
2. handle typo, or
3. page exists but wrong template/default template

### 11. Final QA Checklist Before Publish
1. Desktop and mobile homepage layout
2. Header/footer links open correctly
3. Catalog `Explore/Details` links open correct unit page
4. Contact form submits successfully
5. News subscription submits successfully
6. WhatsApp opens correct number
7. Footer social icons open correct channels
8. Map displays and `View on Google Maps` opens correctly
9. No unintended Chinese appears in rendered website copy
10. Run smoke test in private/incognito window

### 12. Safe Operating Practice
Before major edits:
1. Duplicate current live theme
2. Edit duplicate first
3. Publish only after QA
4. Keep one rollback version available

---

## 中文版本

### 1. 手册范围
本手册用于主题上传后，所有需要在 Shopify 后台手动完成的工作，包括：
1. 页面创建与模板绑定
2. 导航链接一致性
3. 主题编辑器中的图文更新
4. 联系表单与新闻订阅数据去向
5. WhatsApp 与地图行为
6. 404 故障排查

### 2. 上线前关键流程
1. 进入 `Online Store > Themes > Add theme > Upload zip file`
2. 上传 `City-Vallanza-Original-Template-Client-Req.zip`
3. 不要立即发布，先点 `Customize`
4. 按第 3 节完成全部页面与模板绑定
5. 按第 11 节完成检查后再发布

### 3. 必建页面（必须完成）
下列任一 handle 缺失或不一致，都会出现 `404 Not Found`。

| 页面用途 | 必须 Handle | 模板（Theme template 下拉） | 对应 URL |
|---|---|---|---|
| About the Project | `about-project` | `about-project` | `/pages/about-project` |
| Catalog | `catalog` | `catalog` | `/pages/catalog` |
| News | `news` | `news` | `/pages/news` |
| About the Company | `about-company` | `about-company` | `/pages/about-company` |
| Contact | `contact` | `contact` | `/pages/contact` |
| Elite 户型详情 | `elite-vallanza` | `elite-vallanza` | `/pages/elite-vallanza` |
| Signature 户型详情 | `signature-vallanza` | `signature-vallanza` | `/pages/signature-vallanza` |
| Imperial 户型详情 | `imperial-vallanza` | `imperial-vallanza` | `/pages/imperial-vallanza` |
| 未来新增户型示例 | `additional-unit` | `unit-detail` | `/pages/additional-unit` |

每个页面的创建步骤：
1. 进入 `Online Store > Pages > Add page`
2. 填写标题
3. 编辑 URL handle，必须与上表完全一致
4. 在 `Theme template` 选择对应模板
5. 保存

### 4. 导航机制说明（重要）
当前版本的头部和底部导航是固定链接写法。  
因此页面 handle 必须与第 3 节一致。

如果后续修改了 handle，请三选一：
1. 把 handle 改回原值，或
2. 让开发同步改主题链接，或
3. 在 Shopify 做 URL Redirect（旧地址跳转新地址）

### 5. Theme Settings 配置
路径：`Online Store > Themes > Customize > Theme settings`

#### 5.1 Business Information
请填写/确认：
1. `Favicon image`
2. `Business Name`
3. `Contact Phone (WhatsApp)`（建议国际格式，如 `+233 (0) 595 755 557`）
4. `Website`
5. `Contact Email`
6. `Business Address`
7. `Business Google Map Link`

这些信息会被用于：
1. Footer 联系模块
2. Contact 页面信息
3. WhatsApp 按钮唤起
4. 地图外链按钮

#### 5.2 Social Media
请填写/确认：
1. `Facebook`
2. `Instagram`
3. `TikTok`
4. `YouTube`

当前仅在 Footer 图标行展示。

#### 5.3 Brand Colors（VIS）
请设置：
1. `Dark Jungle Green`
2. `Brunswick Green`
3. `Pearl`
4. `Pale Copper`

### 6. 各页面内容维护指南
路径：`Online Store > Themes > Customize`

#### 6.1 首页
主要模块：
1. `Hero`
2. `About`
3. `Featured Properties`
4. `Services`
5. `Testimonials`

关键点：
1. Hero 按钮通常指向 `/pages/catalog` 和 `/pages/contact`
2. 产品卡片链接应指向各自户型详情页
3. Services 的 `Discover More` 指向 `/pages/about-company`

#### 6.2 Catalog 页面
模板：`catalog`  
模块：`Featured Properties`

每个卡片需维护：
1. 户型名、规格
2. 图片
3. `Details Link`（必须对应正确详情页）

#### 6.3 户型详情页（Elite / Signature / Imperial / 后续新增）
模板：`elite-vallanza`、`signature-vallanza`、`imperial-vallanza`、`unit-detail`

模块：`Unit Detail Template`

可维护内容：
1. 头图与户型名
2. 顶部规格图标行
3. 户型图轮播（可点击放大）
4. Amenities 信息
5. Amenities 图片轮播
6. Feature 文本列表
7. 底部 CTA 链接（通常 `/pages/contact`）

#### 6.4 About the Project / About the Company
模板：`about-project`、`about-company`

模块：`About Structured Page`

About Project 建议结构：
1. 项目简介
2. 特色 1
3. 特色 2
4. 特色 3
5. 地图模块开启（`Show Project Address Map`）

About Company 建议结构：
1. 公司简介
2. 理念 1
3. 理念 2
4. 理念 3
5. 地图模块按需开启/关闭

#### 6.5 News 页面
模板：`news`  
模块：`News Cards Page`

可维护内容：
1. 头图与标题
2. 默认 3 条新闻卡（图/标题/100-150 字文案/时间/地点）
3. 订阅说明与 EDM 联系邮箱

该页面无 `Read More` 按钮。

#### 6.6 Contact 页面
模板：`contact`  
模块：`Contact Form Page`

可维护内容：
1. 头图、标题、描述
2. 营业信息文本
3. 地图嵌入 URL
4. 留资表单文案
5. `Unit Interest` 下拉字段：
   - label
   - placeholder
   - options（逗号分隔）

### 7. 表单数据去向
#### 7.1 Contact 留资表单（`form 'contact'`）
通过 Shopify 原生联系流程发送。

后台建议配置：
1. `Settings > General` 设置店铺接收邮箱
2. `Settings > Notifications` 设置发件邮箱与域名认证

#### 7.2 News 订阅（`form 'customer'`）
订阅邮箱进入 Shopify 客户订阅流程，并携带标签：
1. `news-edm`
2. `newsletter`

后续可在 `Customers` 中进行筛选和运营。

### 8. WhatsApp 与悬浮聊天
号码来源：`Theme settings > Business Information > Contact Phone (WhatsApp)`

行为说明：
1. 悬浮按钮与各 WhatsApp CTA 统一使用该号码
2. 若有自定义 chatbot 脚本，可能优先打开 chatbot
3. 无 chatbot 时回退到 WhatsApp 直聊

### 9. 地图语言说明
Google 地图可能按访客浏览器/地区本地化显示。  
如需尽量英文：
1. 地图链接或 embed URL 中带 `hl=en`
2. 同时保留 `View on Google Maps` 外链按钮

### 10. 404 标准排查流程
点击后出现 404 时：
1. 复制失败 URL
2. 到 `Online Store > Pages` 查是否有对应页面
3. 检查 handle 是否与 URL 完全一致
4. 检查 `Theme template` 是否选择正确
5. 保存后用无痕窗口重测

示例：
`/pages/about-company` 出现 404，通常是：
1. 没有 `about-company` 这个 handle 的页面，或
2. handle 拼写错误，或
3. 页面模板选错（选成默认模板）

### 11. 发布前检查清单
1. 首页桌面与移动端布局正常
2. 头部和底部导航链接全部可打开
3. Catalog 的 `Explore/Details` 跳转到正确户型页
4. Contact 表单可提交
5. News 订阅可提交
6. WhatsApp 打开正确号码
7. Footer 社交图标跳转正确账号
8. 地图展示和外链正常
9. 页面展示文案无意外中文残留
10. 使用无痕窗口做一次完整冒烟测试

### 12. 安全运营建议
大改前建议：
1. 先 Duplicate 线上主题
2. 在副本主题改动并测试
3. 验证通过后再 Publish
4. 始终保留一个可回滚版本

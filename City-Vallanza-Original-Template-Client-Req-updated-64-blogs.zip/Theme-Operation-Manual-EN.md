# City Vallanza Shopify Theme Operation Manual (EN)

Applies to: `City-Vallanza-Original-Template-Client-Req.zip`  
Last updated: `2026-03-31`

## 1. Upload Theme
1. Go to `Online Store > Themes`.
2. Click `Add theme > Upload zip file`.
3. Upload `City-Vallanza-Original-Template-Client-Req.zip`.
4. Click `Customize` before publishing.

## 2. Required Pages and Templates
Create these pages in `Online Store > Pages` and assign matching templates.

| Handle | Template | URL |
|---|---|---|
| `about-project` | `about-project` | `/pages/about-project` |
| `catalog` | `catalog` | `/pages/catalog` |
| `news` | `news` | `/pages/news` |
| `about-company` | `about-company` | `/pages/about-company` |
| `contact` | `contact` | `/pages/contact` |
| `elite-vallanza` | `elite-vallanza` | `/pages/elite-vallanza` |
| `signature-vallanza` | `signature-vallanza` | `/pages/signature-vallanza` |
| `imperial-vallanza` | `imperial-vallanza` | `/pages/imperial-vallanza` |
| `additional-unit` | `unit-detail` | `/pages/additional-unit` |

Creation steps:
1. `Add page`.
2. Enter page title.
3. Set URL handle exactly as above.
4. Set `Theme template`.
5. Save.

If handle/template is wrong, links will return `404`.

## 3. Theme Settings
Path: `Online Store > Themes > Customize > Theme settings`.

### 3.1 Business Information
Configure:
1. `Favicon image`
2. `Business Name`
3. `Contact Phone (WhatsApp)`  
Suggested: `+233 (0) 595 755 557`
4. `Website`  
Suggested: `https://www.cityvallanza.com`
5. `Contact Email`  
Suggested: `info@cityvallanza.com`
6. `Business Address`  
Suggested: `Office No.18 3rd Floor, One Airport Square, Airport City, Accra`
7. `Business Google Map Link`

### 3.2 Social Media
Configure:
1. `Facebook`: `https://www.facebook.com/profile.php?id=61578455369337`
2. `Instagram`: `https://www.instagram.com/cityvallanza?igsh=bzFpbHQ1eWI3b3R4`
3. `TikTok`: `https://vm.tiktok.com/ZS9RDbysu6kCV-Lmx51/`
4. `YouTube`: `https://youtube.com/@goldsyngroup?si=G4RyqhHDei9d0-1r`

These links are used in footer social icons.

### 3.3 Brand Colors
Set:
1. `Dark Jungle Green`
2. `Brunswick Green`
3. `Pearl`
4. `Pale Copper`

## 4. Home Page Editing
Path: `Customize > Home page`.

Edit sections:
1. `Hero` (headline, subtitle, CTA)
2. `About`
3. `Featured Properties` (catalog cards)
4. `Services`
5. `Testimonials`

## 5. Catalog and Unit Pages

### 5.1 Catalog page
Template: `catalog`  
Section: `Featured Properties`.

Per property card update:
1. Title
2. Specs
3. Image
4. `Details Link` to correct unit page

### 5.2 Unit detail pages
Templates:
1. `elite-vallanza`
2. `signature-vallanza`
3. `imperial-vallanza`
4. `unit-detail` (for future units)

Section: `Unit Detail Template`.

Update:
1. Hero image and unit name
2. Top stats row
3. Plan gallery images
4. Amenities
5. Feature text
6. Bottom CTA link

## 6. About and News Pages

### 6.1 About Project / About Company
Template: `about-project` / `about-company`  
Section: `About Structured Page`.

About Project:
1. Introduction
2. Feature 1
3. Feature 2
4. Feature 3
5. Map block

About Company:
1. Company introduction
2. Philosophy 1
3. Philosophy 2
4. Philosophy 3

### 6.2 News
Template: `news`  
Section: `News Cards Page`.

Each card:
1. Image
2. Title
3. 100-150 word summary
4. Date
5. Location

Subscription area:
1. Title and copy
2. EDM contact email

## 7. Contact Page
Template: `contact`  
Section: `Contact Form Page`.

Includes:
1. Hero
2. Operating information
3. Embedded map
4. Enquiry form
5. `Unit Interest` dropdown (editable label/placeholder/options)

Contact block target info:
1. `SALES OFFICE`: `Office No.18 3rd Floor, One Airport Square, Airport City, Accra`
2. `CONTACT`: `+233 (0) 595 755 557`
3. `WEBSITE`: `www.cityvallanza.com`
4. `EMAIL`: `info@cityvallanza.com`

## 8. WhatsApp Behavior
All WhatsApp buttons read from `Contact Phone (WhatsApp)` and open direct chat.

Implemented behavior:
1. `(0)` in numbers like `+233 (0) ...` is removed automatically for WhatsApp links.
2. Users do not need to type phone number manually.
3. Floating widget and WhatsApp CTA use the same number.

## 9. Form Routing

### 9.1 Contact form
Type: Shopify native `form 'contact'`.

Configure:
1. `Settings > General` store email
2. `Settings > Notifications` sender email/domain auth

### 9.2 News subscription
Type: Shopify native `form 'customer'`.
Tags added:
1. `news-edm`
2. `newsletter`

## 10. Map Language
Google Maps labels may follow visitor locale.
To prefer English:
1. Use map URL with `hl=en`.
2. Keep `View on Google Maps` link as fallback.

## 11. 404 Troubleshooting
If clicking a link shows `404`:
1. Copy failed URL.
2. Check page exists in `Online Store > Pages`.
3. Check handle matches URL exactly.
4. Check template assignment.
5. Retest in private/incognito window.

## 12. Publish Checklist
1. Desktop and mobile layout
2. Header/footer links
3. Catalog Explore links
4. Unit detail pages
5. Contact form submit
6. News subscription submit
7. WhatsApp direct chat
8. Footer social links
9. Map display and open-in-maps link
10. No unexpected language artifacts

## 13. Safe Workflow
1. Duplicate live theme before major edits.
2. Edit duplicate theme.
3. QA first.
4. Publish only after validation.

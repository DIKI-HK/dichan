# Shopify Page Setup Quick Guide

Create the following pages in Shopify and assign the matching template:

1. `about-project` -> `page.about-project`
2. `catalog` -> `page.catalog`
3. `news` -> `page.news`
4. `about-company` -> `page.about-company`
5. `contact` -> `page.contact`
6. `elite-vallanza` -> `page.elite-vallanza`
7. `signature-vallanza` -> `page.signature-vallanza`
8. `imperial-vallanza` -> `page.imperial-vallanza`
9. `your-new-unit-handle` -> `page.unit-detail` (for future unit additions)

## Steps

1. Go to `Online Store > Pages`.
2. Click `Add page`.
3. Enter the title.
4. In `Theme template`, choose the matching template above.
5. Save.
6. Repeat for all required pages.

## Important

- The navigation and homepage buttons already point to these handles.
- If a page is not created, the link will return 404.
- About Project page uses: project introduction + three project features + project map.
- About Company page uses: company introduction + three company philosophies.
- News page now uses image cards with title, summary, date, and location (no read-more button), plus a newsletter email subscription area for EDM.
- Contact page now uses: hero image + operating information + embedded map + lead form + floating WhatsApp chat widget.

## Reusable Unit Detail Template

Use template `page.unit-detail` when adding a new unit page.

1. Create the page handle in `Online Store > Pages`.
2. In `Customize`, create a new page template based on `page.unit-detail` (for example `page.unit-aurora`).
3. Assign the new template to the page.
4. Open that page in `Customize` and edit section `Unit Detail Template`.
5. Fill:
   - Hero image and unit name
   - Top spec items (icon + text)
   - Plan gallery images
   - Amenities icons/text
   - Feature text list

The gallery supports autoplay and click-to-zoom image viewing.

## Brand Visual Setup (VIS)

To keep colors aligned with the City Vallanza VIS PDF:

1. Go to `Online Store > Themes > Customize`.
2. Open `Theme settings > Brand Colors`.
3. Set the four color tokens:
   - `Dark Jungle Green`
   - `Brunswick Green`
   - `Pearl`
   - `Pale Copper`
4. Save.

These tokens drive the global visual style for hero CTA, section accents, navigation hover states, and footer social icons without changing layout.

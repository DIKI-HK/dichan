# City Vallanza Shopify 主题操作手册（中文）

适用文件：`City-Vallanza-Original-Template-Client-Req.zip`  
更新时间：`2026-03-31`

## 1. 上传主题
1. 进入 `Online Store > Themes`。
2. 点击 `Add theme > Upload zip file`。
3. 上传 `City-Vallanza-Original-Template-Client-Req.zip`。
4. 先点 `Customize`，不要立刻发布。

## 2. 必建页面与模板绑定
在 `Online Store > Pages` 创建以下页面，并绑定对应模板。

| Handle | 模板 | URL |
|---|---|---|
| `about-project` | `about-project` | `/pages/about-project` |
| `catalog` | `catalog` | `/pages/catalog` |
| `news` | `news` | `/pages/news` |
| `about-company` | `about-company` | `/pages/about-company` |
| `contact` | `contact` | `/pages/contact` |
| `elite-vallanza` | `elite-vallanza` | `/pages/elite-vallanza` |
| `signature-vallanza` | `signature-vallanza` | `/pages/signature-vallanza` |
| `imperial-vallanza` | `imperial-vallanza` | `/pages/imperial-vallanza` |
| `additional-unit` | `unit-detail` | `/pages/additional-unit` |

创建步骤：
1. 点击 `Add page`。
2. 输入标题。
3. URL handle 必须与上表一致。
4. 在 `Theme template` 选择对应模板。
5. 保存。

只要 handle 或模板不一致，就会出现 `404`。

## 3. Theme Settings 配置
路径：`Online Store > Themes > Customize > Theme settings`。

### 3.1 Business Information
请填写：
1. `Favicon image`
2. `Business Name`
3. `Contact Phone (WhatsApp)`  
建议：`+233 (0) 595 755 557`
4. `Website`  
建议：`https://www.cityvallanza.com`
5. `Contact Email`  
建议：`info@cityvallanza.com`
6. `Business Address`  
建议：`Office No.18 3rd Floor, One Airport Square, Airport City, Accra`
7. `Business Google Map Link`

### 3.2 Social Media
请填写：
1. `Facebook`：`https://www.facebook.com/profile.php?id=61578455369337`
2. `Instagram`：`https://www.instagram.com/cityvallanza?igsh=bzFpbHQ1eWI3b3R4`
3. `TikTok`：`https://vm.tiktok.com/ZS9RDbysu6kCV-Lmx51/`
4. `YouTube`：`https://youtube.com/@goldsyngroup?si=G4RyqhHDei9d0-1r`

这些地址用于页脚社交图标。

### 3.3 Brand Colors
按 VIS 设置：
1. `Dark Jungle Green`
2. `Brunswick Green`
3. `Pearl`
4. `Pale Copper`

## 4. 首页维护
路径：`Customize > Home page`。

重点模块：
1. `Hero`
2. `About`
3. `Featured Properties`
4. `Services`
5. `Testimonials`

## 5. Catalog 与户型详情页

### 5.1 Catalog 页面
模板：`catalog`  
模块：`Featured Properties`。

每个卡片维护：
1. 名称
2. 规格
3. 图片
4. `Details Link`（指向正确户型详情页）

### 5.2 户型详情页
模板：
1. `elite-vallanza`
2. `signature-vallanza`
3. `imperial-vallanza`
4. `unit-detail`（后续新增户型）

模块：`Unit Detail Template`。

可维护内容：
1. 头图与户型名
2. 顶部规格行
3. 户型图轮播
4. Amenities
5. Feature 文案
6. 底部 CTA

## 6. About 与 News 页面

### 6.1 About Project / About Company
模板：`about-project` / `about-company`  
模块：`About Structured Page`。

About Project 建议结构：
1. 项目简介
2. 特色 1
3. 特色 2
4. 特色 3
5. 地图模块

About Company 建议结构：
1. 公司简介
2. 理念 1
3. 理念 2
4. 理念 3

### 6.2 News 页面
模板：`news`  
模块：`News Cards Page`。

每条新闻卡：
1. 图片
2. 标题
3. 100-150 字摘要
4. 时间
5. 地点

订阅区：
1. 标题/说明
2. EDM 联系邮箱

## 7. Contact 页面
模板：`contact`  
模块：`Contact Form Page`。

包含：
1. 头图
2. 营业信息
3. 地图
4. 留资表单
5. `Unit Interest` 下拉项（可后台改 label/placeholder/options）

联系信息目标值：
1. `SALES OFFICE`：`Office No.18 3rd Floor, One Airport Square, Airport City, Accra`
2. `CONTACT`：`+233 (0) 595 755 557`
3. `WEBSITE`：`www.cityvallanza.com`
4. `EMAIL`：`info@cityvallanza.com`

## 8. WhatsApp 规则
所有 WhatsApp 按钮统一读取 `Contact Phone (WhatsApp)` 并直接发起聊天。

已实现：
1. 自动去除 `+233 (0) ...` 中的 `(0)`，避免号码错误。
2. 用户点击后不需要手输号码。
3. 悬浮按钮、卡片按钮、联系区按钮使用同一号码。

## 9. 表单数据去向

### 9.1 Contact 留资
使用 Shopify 原生 `form 'contact'`。

后台建议：
1. `Settings > General` 配置接收邮箱。
2. `Settings > Notifications` 配置发件邮箱和域名认证。

### 9.2 News 订阅
使用 Shopify 原生 `form 'customer'`，自动打标签：
1. `news-edm`
2. `newsletter`

可在 `Customers` 中筛选处理。

## 10. 地图语言
Google Map 标签可能跟随访客语言。
如需尽量英文：
1. 地图 URL 使用 `hl=en`。
2. 保留 `View on Google Maps` 外链按钮。

## 11. 404 排查
点击出现 404 时：
1. 复制失败 URL。
2. 到 `Online Store > Pages` 检查该页面是否存在。
3. 检查 handle 是否一致。
4. 检查模板是否绑定正确。
5. 用无痕窗口重测。

## 12. 发布前检查清单
1. 桌面端和移动端布局
2. 头部/底部导航
3. Catalog 的 Explore 跳转
4. 户型详情页显示
5. Contact 表单提交
6. News 订阅提交
7. WhatsApp 一键直聊
8. 社交图标跳转
9. 地图展示与外链
10. 无异常语言残留

## 13. 安全操作建议
1. 大改前先 Duplicate 当前线上主题。
2. 先在副本编辑测试。
3. QA 通过再发布。
4. 至少保留一个可回滚版本。
